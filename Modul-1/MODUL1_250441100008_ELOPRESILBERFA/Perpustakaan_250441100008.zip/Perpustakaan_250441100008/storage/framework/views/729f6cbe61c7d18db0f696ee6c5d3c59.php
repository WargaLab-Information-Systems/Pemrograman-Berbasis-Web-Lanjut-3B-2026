<div class="book-card">


    <div class="book-content">

        <span class="book-category">
            <?php echo e($buku['kategori']); ?>

        </span>

        <h3>
            <?php echo e($buku['judul']); ?>

        </h3>

        <p class="book-author">
            <?php echo e($buku['penulis']); ?>

        </p>

        <div class="book-year">
            <span>Terbit</span>
            <?php echo e($buku['tahun']); ?>

        </div>

        <div class="book-action">

            <?php echo e($detail); ?>


        </div>

    </div>

</div><?php /**PATH C:\laragon\www\Perpustakaan_250441100008\resources\views/components/buku-card.blade.php ENDPATH**/ ?>