

<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>

<section class="hero">


    <div class="hero-container">

        <div class="hero-text">

            <h1>
                Selamat Datang di
                <span>PerpustakaanKu</span>
            </h1>

            <p class="hero-description">
                Temukan berbagai koleksi buku untuk menambah
                pengetahuan, wawasan, dan inspirasi.
            </p>

            <p class="hero-info">
                Jelajahi koleksi buku kami dengan mudah dan nyaman.
            </p>

            <a href="<?php echo e(route('buku.index')); ?>" class="hero-button">
                Jelajahi Buku
                <span>→</span>
            </a>

        </div>

    </div>

</section>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Perpustakaan_250441100008\resources\views/home.blade.php ENDPATH**/ ?>