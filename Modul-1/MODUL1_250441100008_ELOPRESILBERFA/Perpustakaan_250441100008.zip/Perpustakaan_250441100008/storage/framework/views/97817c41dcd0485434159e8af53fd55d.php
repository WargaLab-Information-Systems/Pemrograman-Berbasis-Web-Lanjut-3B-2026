<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title'); ?> - PerpustakaanKu</title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
</head>

<body>

    <nav class="navbar">

        <div class="nav-container">

            <a href="<?php echo e(route('home')); ?>" class="brand">

                <div class="brand-text">
                    <strong>PerpustakaanKu</strong>
                </div>
            </a>

            <div class="nav-menu">

                <a href="<?php echo e(route('home')); ?>"
                   class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">
                    Beranda
                </a>

                <a href="<?php echo e(route('buku.index')); ?>"
                   class="<?php echo e(request()->routeIs('buku.*') ? 'active' : ''); ?>">
                    Daftar Buku
                </a>

            </div>

        </div>

    </nav>


    <main>

        <?php echo $__env->yieldContent('content'); ?>

    </main>


    <footer>

        <div class="footer-container">

            <div>
                <div class="footer-brand">
                    PerpustakaanKu
                </div>

                <p>
                    Menjelajahi dunia melalui buku.
                </p>
            </div>

            <p class="copyright">
                © 2026 PerpustakaanKu
            </p>

        </div>

    </footer>

</body>

</html><?php /**PATH C:\laragon\www\Perpustakaan_250441100008\resources\views/layouts/app.blade.php ENDPATH**/ ?>