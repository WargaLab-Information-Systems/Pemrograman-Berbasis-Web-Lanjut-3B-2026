

<?php $__env->startSection('title', 'Detail Buku'); ?>

<?php $__env->startSection('content'); ?>

<section class="detail-page">

    <a href="<?php echo e(route('buku.index')); ?>" class="back-button">
        ← Kembali ke Daftar Buku
    </a>


    <?php if($buku): ?>

        <div class="detail-container">


            <div class="detail-information">

                <span class="page-label">
                    DETAIL BUKU
                </span>

                <h1>
                    <?php echo e($buku['judul']); ?>

                </h1>

                <p class="detail-author">
                    Ditulis oleh
                    <strong><?php echo e($buku['penulis']); ?></strong>
                </p>


                <div class="detail-list">

                    <div>
                        <span>ID Buku</span>
                        <strong><?php echo e($buku['id']); ?></strong>
                    </div>

                    <div>
                        <span>Tahun Terbit</span>
                        <strong><?php echo e($buku['tahun']); ?></strong>
                    </div>

                    <div>
                        <span>Kategori</span>
                        <strong><?php echo e($buku['kategori']); ?></strong>
                    </div>

                </div>


                <p class="detail-description">
                    Buku ini merupakan bagian dari koleksi
                    Perpustakaan Digital dan dapat digunakan
                    sebagai sumber bacaan dan pengetahuan.
                </p>


                <a
                    href="<?php echo e(route('buku.index')); ?>"
                    class="hero-button"
                >
                    ← Kembali
                </a>

            </div>

        </div>

    <?php else: ?>

        <div class="empty-book">

            <h2>
                Buku Tidak Ditemukan
            </h2>

            <p>
                Data buku yang kamu cari tidak tersedia.
            </p>

            <a
                href="<?php echo e(route('buku.index')); ?>"
                class="hero-button"
            >
                Kembali ke Daftar Buku
            </a>

        </div>

    <?php endif; ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Perpustakaan_250441100008\resources\views/buku-detail.blade.php ENDPATH**/ ?>