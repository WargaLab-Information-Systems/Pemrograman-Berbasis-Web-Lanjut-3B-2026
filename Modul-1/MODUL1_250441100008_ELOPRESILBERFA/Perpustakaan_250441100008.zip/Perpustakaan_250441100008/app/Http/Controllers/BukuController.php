<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BukuController extends Controller
{
    public $buku = [
        [
            'id' => 1,
            'judul' => 'Seporsi Mie Ayam Sebelum Mati',
            'penulis' => 'Brian Khrisna',
            'tahun' => 2025,
            'kategori' => 'Novel'
        ],
        [
            'id' => 2,
            'judul' => 'Planet Luna',
            'penulis' => 'Ray Antariksa Yasmine',
            'tahun' => 2023,
            'kategori' => 'Fantasi'
        ],
        [
            'id' => 3,
            'judul' => 'Madilog',
            'penulis' => 'Tan Malaka',
            'tahun' => 1943,
            'kategori' => 'Non-Fiksi'
        ],
        [
            'id' => 4,
            'judul' => ' Koala Kumal ',
            'penulis' => 'Raditya Dika',
            'tahun' => 2016,
            'kategori' => 'Non-Fiksi'
        ],
        [
            'id' => 5,
            'judul' => 'Hujan',
            'penulis' => 'Tere Liye',
            'tahun' => 2016,
            'kategori' => 'Novel'
        ]
    ];

    public function index()
    {
        return view('buku', ['buku' => $this->buku]);
    }

    public function show($id)
    {
        $detailBuku = null;

        foreach ($this->buku as $data) {
            if ($data['id'] == $id) {
                $detailBuku = $data;
            }
        }

        return view('buku-detail', ['buku' => $detailBuku]);
    }
}