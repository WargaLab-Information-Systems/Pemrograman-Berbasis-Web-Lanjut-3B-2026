<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>@yield('title') - PerpustakaanKu</title>

    @vite(['resources/css/app.css'])
</head>

<body>

    <nav class="navbar">

        <div class="nav-container">

            <a href="{{ route('home') }}" class="brand">

                <div class="brand-text">
                    <strong>PerpustakaanKu</strong>
                </div>
            </a>

            <div class="nav-menu">

                <a href="{{ route('home') }}"
                   class="{{ request()->routeIs('home') ? 'active' : '' }}">
                    Beranda
                </a>

                <a href="{{ route('buku.index') }}"
                   class="{{ request()->routeIs('buku.*') ? 'active' : '' }}">
                    Daftar Buku
                </a>

            </div>

        </div>

    </nav>


    <main>

        @yield('content')

    </main>


    <footer>

        <div class="footer-container">

            <div>
                <div class="footer-brand">
                    PerpustakaanKu
                </div>

                <p>
                    Menjelajahi dunia melalui buku.
                </p>
            </div>

            <p class="copyright">
                © 2026 PerpustakaanKu
            </p>

        </div>

    </footer>

</body>

</html>