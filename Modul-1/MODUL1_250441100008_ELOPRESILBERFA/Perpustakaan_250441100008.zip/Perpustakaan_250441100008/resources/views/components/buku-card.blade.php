<div class="book-card">


    <div class="book-content">

        <span class="book-category">
            {{ $buku['kategori'] }}
        </span>

        <h3>
            {{ $buku['judul'] }}
        </h3>

        <p class="book-author">
            {{ $buku['penulis'] }}
        </p>

        <div class="book-year">
            <span>Terbit</span>
            {{ $buku['tahun'] }}
        </div>

        <div class="book-action">

            {{ $detail }}

        </div>

    </div>

</div>