@extends('layouts.app')

@section('title', 'Daftar Buku')

@section('content')

<section class="books-page">

    <div class="page-intro">

        <div>

            <h1>
                Daftar Buku
            </h1>

            <p>
                Jelajahi berbagai koleksi buku yang tersedia
                di perpustakaanKu.
            </p>

        </div>

    </div>


    <div class="books-grid">

        @foreach ($buku as $data)

            <x-buku-card :buku="$data">

                <x-slot:detail>

                    <a
                        href="{{ route('buku.show', $data['id']) }}"
                        class="detail-button"
                    >
                        Lihat Detail
                        <span>→</span>
                    </a>

                </x-slot:detail>

            </x-buku-card>

        @endforeach

    </div>

</section>

@endsection